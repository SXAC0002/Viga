import React, { useState, useMemo, useRef, useEffect, useCallback } from "react";

/* ============================================================
   ANALIZADOR DE VIGA CONTINUA — Método directo de la rigidez
   Elemento viga Euler-Bernoulli, 2 GDL por nodo (v, θ)
   Convención: v ↑ positivo, θ CCW positivo, kN y m
   ============================================================ */

const r6 = (v) => Math.round(v * 1e6) / 1e6;

function solveLinear(Aflat, b, n) {
  // Gauss con pivoteo parcial sobre matriz aumentada densa
  const M = new Float64Array(n * (n + 1));
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) M[i * (n + 1) + j] = Aflat[i * n + j];
    M[i * (n + 1) + n] = b[i];
  }
  for (let c = 0; c < n; c++) {
    let piv = c;
    for (let r = c + 1; r < n; r++)
      if (Math.abs(M[r * (n + 1) + c]) > Math.abs(M[piv * (n + 1) + c])) piv = r;
    if (Math.abs(M[piv * (n + 1) + c]) < 1e-9) return null; // mecanismo
    if (piv !== c)
      for (let k = c; k <= n; k++) {
        const t = M[c * (n + 1) + k];
        M[c * (n + 1) + k] = M[piv * (n + 1) + k];
        M[piv * (n + 1) + k] = t;
      }
    const d = M[c * (n + 1) + c];
    for (let r = c + 1; r < n; r++) {
      const f = M[r * (n + 1) + c] / d;
      if (f === 0) continue;
      for (let k = c; k <= n; k++) M[r * (n + 1) + k] -= f * M[c * (n + 1) + k];
    }
  }
  const x = new Float64Array(n);
  for (let r = n - 1; r >= 0; r--) {
    let s = M[r * (n + 1) + n];
    for (let k = r + 1; k < n; k++) s -= M[r * (n + 1) + k] * x[k];
    x[r] = s / M[r * (n + 1) + r];
  }
  return x;
}

function analyze(spans, supports, pointLoads, EI) {
  const bounds = [0];
  let acc = 0;
  for (const s of spans) {
    acc = r6(acc + s.L);
    bounds.push(acc);
  }
  const Ltot = acc;
  if (Ltot <= 0) return { error: "Define al menos un tramo con longitud mayor que cero." };

  // malla: nodos en apoyos, en cargas puntuales, y subdivisión uniforme
  const keySet = new Set(bounds);
  for (const p of pointLoads) {
    const x = r6(Math.min(Math.max(p.x, 0), Ltot));
    keySet.add(x);
  }
  const keys = [...keySet].sort((a, b) => a - b);
  const dxTarget = Ltot / 120;
  const X = [];
  for (let i = 0; i < keys.length - 1; i++) {
    const a = keys[i], b = keys[i + 1];
    const n = Math.max(1, Math.round((b - a) / dxTarget));
    for (let j = 0; j < n; j++) X.push(a + ((b - a) * j) / n);
  }
  X.push(keys[keys.length - 1]);

  const nn = X.length;
  const nd = 2 * nn;
  const K = new Float64Array(nd * nd);
  const P = new Float64Array(nd);

  const wAt = (xm) => {
    let a = 0;
    for (const s of spans) {
      if (xm >= a - 1e-9 && xm <= a + s.L + 1e-9) return s.w;
      a += s.L;
    }
    return 0;
  };

  const elems = [];
  for (let e = 0; e < nn - 1; e++) {
    const L = X[e + 1] - X[e];
    const w = wAt((X[e] + X[e + 1]) / 2);
    const c = EI / (L * L * L);
    const k = [
      [12 * c, 6 * L * c, -12 * c, 6 * L * c],
      [6 * L * c, 4 * L * L * c, -6 * L * c, 2 * L * L * c],
      [-12 * c, -6 * L * c, 12 * c, -6 * L * c],
      [6 * L * c, 2 * L * L * c, -6 * L * c, 4 * L * L * c],
    ];
    // fuerzas de empotramiento perfecto para w ↓ (V ↑ +, M CCW +)
    const fef = [(w * L) / 2, (w * L * L) / 12, (w * L) / 2, (-w * L * L) / 12];
    const map = [2 * e, 2 * e + 1, 2 * e + 2, 2 * e + 3];
    for (let i = 0; i < 4; i++) {
      P[map[i]] -= fef[i];
      for (let j = 0; j < 4; j++) K[map[i] * nd + map[j]] += k[i][j];
    }
    elems.push({ k, fef, map, L, w });
  }

  // cargas puntuales -> nodo más cercano (coincide exacto por construcción)
  for (const p of pointLoads) {
    const x = Math.min(Math.max(p.x, 0), Ltot);
    let idx = 0, best = Infinity;
    for (let i = 0; i < nn; i++) {
      const d = Math.abs(X[i] - x);
      if (d < best) { best = d; idx = i; }
    }
    P[2 * idx] -= p.P; // P hacia abajo
  }

  // condiciones de borde
  const fixed = new Set();
  const supNode = [];
  bounds.forEach((bx, i) => {
    let idx = 0, best = Infinity;
    for (let j = 0; j < nn; j++) {
      const d = Math.abs(X[j] - bx);
      if (d < best) { best = d; idx = j; }
    }
    supNode.push(idx);
    const t = supports[i]?.type ?? "apoyo";
    if (t === "apoyo") fixed.add(2 * idx);
    if (t === "empotrado") { fixed.add(2 * idx); fixed.add(2 * idx + 1); }
  });

  const free = [];
  for (let i = 0; i < nd; i++) if (!fixed.has(i)) free.push(i);
  const nf = free.length;
  const Kr = new Float64Array(nf * nf);
  const Pr = new Float64Array(nf);
  for (let i = 0; i < nf; i++) {
    Pr[i] = P[free[i]];
    for (let j = 0; j < nf; j++) Kr[i * nf + j] = K[free[i] * nd + free[j]];
  }
  const dr = solveLinear(Kr, Pr, nf);
  if (!dr) return { error: "La viga es un mecanismo: faltan apoyos para restringirla." };

  const d = new Float64Array(nd);
  for (let i = 0; i < nf; i++) d[free[i]] = dr[i];

  // reacciones: R = K·d − P
  const reactions = supNode.map((idx, i) => {
    const t = supports[i]?.type ?? "apoyo";
    if (t === "libre") return null;
    let Rv = -P[2 * idx], Rm = -P[2 * idx + 1];
    for (let j = 0; j < nd; j++) {
      Rv += K[2 * idx * nd + j] * d[j];
      Rm += K[(2 * idx + 1) * nd + j] * d[j];
    }
    return { x: X[idx], V: Rv, M: t === "empotrado" ? Rm : 0, type: t };
  });

  // esfuerzos internos en extremos de elemento
  const V = [], Mo = [], De = [];
  elems.forEach((el, e) => {
    const dv = el.map.map((m) => d[m]);
    const f = [0, 0, 0, 0];
    for (let i = 0; i < 4; i++) {
      let s = el.fef[i];
      for (let j = 0; j < 4; j++) s += el.k[i][j] * dv[j];
      f[i] = s;
    }
    V.push({ x: X[e], v: f[0] });
    V.push({ x: X[e + 1], v: -f[2] });
    Mo.push({ x: X[e], v: -f[1] });
    Mo.push({ x: X[e + 1], v: f[3] });
  });
  for (let i = 0; i < nn; i++) De.push({ x: X[i], v: d[2 * i] });

  const ext = (arr) => {
    let mx = { x: 0, v: 0 }, mn = { x: 0, v: 0 };
    for (const p of arr) {
      if (p.v > mx.v) mx = p;
      if (p.v < mn.v) mn = p;
    }
    return { max: mx, min: mn, abs: Math.max(Math.abs(mx.v), Math.abs(mn.v)) };
  };

  return { X, V, M: Mo, D: De, reactions, bounds, Ltot, eV: ext(V), eM: ext(Mo), eD: ext(De) };
}

/* ---------------------------- UI ---------------------------- */

const PRESETS = {
  simple: { name: "Simplemente apoyada", spans: [{ L: 6, w: 25 }], supports: [{ type: "apoyo" }, { type: "apoyo" }], loads: [] },
  voladizo: { name: "Voladizo", spans: [{ L: 3, w: 15 }], supports: [{ type: "empotrado" }, { type: "libre" }], loads: [{ x: 3, P: 30 }] },
  continua: { name: "Continua 2 tramos", spans: [{ L: 6, w: 25 }, { L: 6, w: 25 }], supports: [{ type: "apoyo" }, { type: "apoyo" }, { type: "apoyo" }], loads: [{ x: 9, P: 50 }] },
  biempotrada: { name: "Biempotrada", spans: [{ L: 7, w: 30 }], supports: [{ type: "empotrado" }, { type: "empotrado" }], loads: [] },
};

const fmt = (v, n = 2) => (Math.abs(v) < 5e-3 ? 0 : v).toFixed(n);

function Field({ value, unit, onChange, step = 0.5, min = 0 }) {
  return (
    <div className="vc-field">
      <input
        type="number"
        value={value}
        step={step}
        min={min}
        onChange={(e) => onChange(parseFloat(e.target.value) || 0)}
      />
      <span>{unit}</span>
    </div>
  );
}

export default function App() {
  const [spans, setSpans] = useState(PRESETS.continua.spans);
  const [supports, setSupports] = useState(PRESETS.continua.supports);
  const [loads, setLoads] = useState(PRESETS.continua.loads);
  const [sec, setSec] = useState({ b: 30, h: 50, E: 25 });
  const [hover, setHover] = useState(null);

  const wrapRef = useRef(null);
  const [W, setW] = useState(760);
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const ro = new ResizeObserver((en) => setW(Math.max(280, en[0].contentRect.width)));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const I = useMemo(() => ((sec.b / 100) * Math.pow(sec.h / 100, 3)) / 12, [sec]);
  const EI = useMemo(() => sec.E * 1e6 * I, [sec.E, I]);
  const res = useMemo(() => analyze(spans, supports, loads, EI), [spans, supports, loads, EI]);

  const applyPreset = (k) => {
    const p = PRESETS[k];
    setSpans(p.spans.map((s) => ({ ...s })));
    setSupports(p.supports.map((s) => ({ ...s })));
    setLoads(p.loads.map((l) => ({ ...l })));
    setHover(null);
  };

  const setSpan = (i, key, val) =>
    setSpans((s) => s.map((sp, j) => (j === i ? { ...sp, [key]: val } : sp)));

  const addSpan = () => {
    setSpans((s) => [...s, { L: 6, w: 25 }]);
    setSupports((s) => [...s, { type: "apoyo" }]);
  };
  const delSpan = (i) => {
    if (spans.length === 1) return;
    setSpans((s) => s.filter((_, j) => j !== i));
    setSupports((s) => s.filter((_, j) => j !== i + 1));
  };

  const Ltot = spans.reduce((a, s) => a + s.L, 0);

  // ---- geometría de dibujo ----
  const PAD = { l: 46, r: 22 };
  const plotW = Math.max(120, W - PAD.l - PAD.r);
  const xs = (x) => PAD.l + (x / (Ltot || 1)) * plotW;
  const fromPx = (px) => ((px - PAD.l) / plotW) * Ltot;

  const sample = useCallback(
    (arr, x) => {
      if (!arr || !arr.length) return 0;
      for (let i = 0; i < arr.length - 1; i++) {
        const a = arr[i], b = arr[i + 1];
        if (x >= a.x - 1e-9 && x <= b.x + 1e-9) {
          if (b.x - a.x < 1e-9) return b.v;
          return a.v + ((b.v - a.v) * (x - a.x)) / (b.x - a.x);
        }
      }
      return arr[arr.length - 1].v;
    },
    []
  );

  const onMove = (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    const x = fromPx(e.clientX - r.left);
    if (x < -0.2 || x > Ltot + 0.2) return setHover(null);
    setHover(Math.min(Math.max(x, 0), Ltot));
  };

  const css = `
  @import url('https://fonts.googleapis.com/css2?family=Archivo+Narrow:wght@500;600;700&family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500&display=swap');
  .vc { --paper:#F3F6F4; --grid:#DCE4E1; --ink:#15232A; --soft:#63747B; --rule:#C2CDC9;
        --shear:#0F7B8A; --moment:#A33055; --defl:#9A6410;
        background:var(--paper); color:var(--ink); font-family:'IBM Plex Sans',system-ui,sans-serif;
        min-height:100%; padding:18px; box-sizing:border-box; }
  .vc *, .vc *::before, .vc *::after { box-sizing:border-box; }
  .vc-titleblock { border:1.5px solid var(--ink); display:grid; grid-template-columns:1fr auto; align-items:stretch; }
  .vc-tb-main { padding:12px 16px; }
  .vc-tb-side { border-left:1.5px solid var(--ink); padding:10px 14px; display:flex; gap:22px; align-items:center; }
  .vc h1 { font-family:'Archivo Narrow',sans-serif; font-weight:700; font-size:26px; letter-spacing:.02em;
           text-transform:uppercase; margin:0; line-height:1; }
  .vc .sub { font-family:'IBM Plex Mono',monospace; font-size:11px; color:var(--soft); letter-spacing:.09em;
             text-transform:uppercase; margin-top:6px; }
  .vc .stat-l { font-family:'IBM Plex Mono',monospace; font-size:9.5px; letter-spacing:.12em; color:var(--soft); text-transform:uppercase; }
  .vc .stat-v { font-family:'IBM Plex Mono',monospace; font-size:15px; font-weight:600; margin-top:2px; }
  .vc-grid { display:grid; grid-template-columns:296px 1fr; gap:16px; margin-top:16px; align-items:start; }
  @media (max-width:820px){ .vc-grid { grid-template-columns:1fr; } .vc-rail { order:2; } }
  .vc-card { border:1px solid var(--rule); background:#fff; }
  .vc-card + .vc-card { margin-top:12px; }
  .vc-card > h2 { font-family:'Archivo Narrow',sans-serif; text-transform:uppercase; letter-spacing:.1em;
      font-size:11.5px; font-weight:700; margin:0; padding:8px 12px; border-bottom:1px solid var(--rule); color:var(--ink); }
  .vc-card .body { padding:12px; }
  .vc-row { display:grid; grid-template-columns:18px 1fr 1fr 22px; gap:6px; align-items:center; margin-bottom:6px; }
  .vc-idx { font-family:'IBM Plex Mono',monospace; font-size:11px; color:var(--soft); }
  .vc-field { position:relative; }
  .vc-field input { width:100%; font-family:'IBM Plex Mono',monospace; font-size:13px; padding:6px 26px 6px 8px;
      border:1px solid var(--rule); background:var(--paper); color:var(--ink); border-radius:0; }
  .vc-field input:focus { outline:2px solid var(--ink); outline-offset:-1px; }
  .vc-field span { position:absolute; right:6px; top:50%; transform:translateY(-50%);
      font-family:'IBM Plex Mono',monospace; font-size:10px; color:var(--soft); pointer-events:none; }
  .vc-lab { font-family:'IBM Plex Mono',monospace; font-size:9.5px; letter-spacing:.1em; color:var(--soft);
      text-transform:uppercase; margin-bottom:5px; }
  .vc-btn { font-family:'IBM Plex Mono',monospace; font-size:11px; letter-spacing:.06em; padding:5px 9px;
      border:1px solid var(--rule); background:#fff; color:var(--ink); cursor:pointer; }
  .vc-btn:hover { background:var(--ink); color:#fff; border-color:var(--ink); }
  .vc-btn:focus-visible { outline:2px solid var(--ink); outline-offset:2px; }
  .vc-x { border:none; background:none; color:var(--soft); cursor:pointer; font-size:15px; line-height:1; padding:2px 4px; }
  .vc-x:hover { color:var(--moment); }
  .vc-seg { display:flex; border:1px solid var(--rule); }
  .vc-seg button { flex:1; font-family:'IBM Plex Mono',monospace; font-size:10px; padding:5px 2px; border:none;
      background:#fff; color:var(--soft); cursor:pointer; letter-spacing:.04em; }
  .vc-seg button + button { border-left:1px solid var(--rule); }
  .vc-seg button[data-on="1"] { background:var(--ink); color:#fff; }
  .vc-sheet { border:1px solid var(--rule); background:#fff; }
  .vc-panel + .vc-panel { border-top:1px solid var(--rule); }
  .vc-tags { display:flex; flex-wrap:wrap; gap:6px; }
  .vc-react { width:100%; border-collapse:collapse; font-family:'IBM Plex Mono',monospace; font-size:12px; }
  .vc-react th { font-size:9.5px; letter-spacing:.1em; text-transform:uppercase; color:var(--soft);
      text-align:right; font-weight:500; padding:4px 10px; border-bottom:1px solid var(--rule); }
  .vc-react th:first-child, .vc-react td:first-child { text-align:left; }
  .vc-react td { padding:5px 10px; border-bottom:1px solid var(--grid); text-align:right; }
  .vc-err { padding:26px; font-family:'IBM Plex Mono',monospace; font-size:13px; color:var(--moment); }
  @media (prefers-reduced-motion:no-preference){ .vc-anim { animation:vcIn .5s ease-out both; } }
  @keyframes vcIn { from { opacity:0; transform:translateY(6px);} to {opacity:1; transform:none;} }
  `;

  return (
    <div className="vc">
      <style>{css}</style>

      <div className="vc-titleblock">
        <div className="vc-tb-main">
          <h1>Viga continua — análisis matricial</h1>
          <div className="sub">Método directo de la rigidez · elemento Euler-Bernoulli · kN, m</div>
        </div>
        <div className="vc-tb-side">
          <div>
            <div className="stat-l">Sección</div>
            <div className="stat-v">{sec.b}×{sec.h} cm</div>
          </div>
          <div>
            <div className="stat-l">EI</div>
            <div className="stat-v">{(EI / 1000).toFixed(1)}e3</div>
          </div>
          <div>
            <div className="stat-l">Estación</div>
            <div className="stat-v" style={{ color: hover == null ? "#63747B" : "#15232A" }}>
              {hover == null ? "—" : `x = ${hover.toFixed(2)} m`}
            </div>
          </div>
        </div>
      </div>

      <div className="vc-grid">
        {/* ------------------- RAIL DE CONTROLES ------------------- */}
        <div className="vc-rail">
          <div className="vc-card">
            <h2>Modelos rápidos</h2>
            <div className="body vc-tags">
              {Object.entries(PRESETS).map(([k, p]) => (
                <button key={k} className="vc-btn" onClick={() => applyPreset(k)}>
                  {p.name}
                </button>
              ))}
            </div>
          </div>

          <div className="vc-card">
            <h2>Tramos</h2>
            <div className="body">
              <div className="vc-row" style={{ marginBottom: 8 }}>
                <div />
                <div className="vc-lab" style={{ margin: 0 }}>Luz</div>
                <div className="vc-lab" style={{ margin: 0 }}>Carga w</div>
                <div />
              </div>
              {spans.map((s, i) => (
                <div className="vc-row" key={i}>
                  <div className="vc-idx">{i + 1}</div>
                  <Field value={s.L} unit="m" onChange={(v) => setSpan(i, "L", Math.max(0.1, v))} />
                  <Field value={s.w} unit="kN/m" step={1} onChange={(v) => setSpan(i, "w", v)} />
                  <button className="vc-x" onClick={() => delSpan(i)} aria-label={`Eliminar tramo ${i + 1}`}>×</button>
                </div>
              ))}
              <button className="vc-btn" onClick={addSpan} style={{ marginTop: 4 }}>+ Agregar tramo</button>
            </div>
          </div>

          <div className="vc-card">
            <h2>Apoyos</h2>
            <div className="body">
              {supports.map((sp, i) => (
                <div key={i} style={{ marginBottom: 8 }}>
                  <div className="vc-lab">Nodo {i + 1} · x = {spans.slice(0, i).reduce((a, s) => a + s.L, 0).toFixed(2)} m</div>
                  <div className="vc-seg">
                    {["apoyo", "empotrado", "libre"].map((t) => (
                      <button
                        key={t}
                        data-on={sp.type === t ? "1" : "0"}
                        onClick={() => setSupports((s) => s.map((q, j) => (j === i ? { type: t } : q)))}
                      >
                        {t === "apoyo" ? "APOYO" : t === "empotrado" ? "EMPOTR." : "LIBRE"}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="vc-card">
            <h2>Cargas puntuales</h2>
            <div className="body">
              {loads.length === 0 && (
                <div style={{ fontSize: 12, color: "#63747B", marginBottom: 8 }}>
                  Sin cargas puntuales. Agrega una para ver el quiebre en el cortante.
                </div>
              )}
              {loads.map((l, i) => (
                <div className="vc-row" key={i}>
                  <div className="vc-idx">P{i + 1}</div>
                  <Field value={l.x} unit="m" onChange={(v) => setLoads((s) => s.map((q, j) => (j === i ? { ...q, x: Math.min(Math.max(v, 0), Ltot) } : q)))} />
                  <Field value={l.P} unit="kN" step={5} onChange={(v) => setLoads((s) => s.map((q, j) => (j === i ? { ...q, P: v } : q)))} />
                  <button className="vc-x" onClick={() => setLoads((s) => s.filter((_, j) => j !== i))} aria-label={`Eliminar carga ${i + 1}`}>×</button>
                </div>
              ))}
              <button className="vc-btn" onClick={() => setLoads((s) => [...s, { x: Math.round(Ltot / 2 * 2) / 2, P: 40 }])} style={{ marginTop: 4 }}>
                + Agregar carga
              </button>
            </div>
          </div>

          <div className="vc-card">
            <h2>Sección y material</h2>
            <div className="body">
              <div className="vc-row" style={{ gridTemplateColumns: "1fr 1fr 1fr" }}>
                <Field value={sec.b} unit="cm" step={5} onChange={(v) => setSec((s) => ({ ...s, b: Math.max(5, v) }))} />
                <Field value={sec.h} unit="cm" step={5} onChange={(v) => setSec((s) => ({ ...s, h: Math.max(5, v) }))} />
                <Field value={sec.E} unit="GPa" step={1} onChange={(v) => setSec((s) => ({ ...s, E: Math.max(1, v) }))} />
              </div>
              <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 11, color: "#63747B", marginTop: 8 }}>
                I = {(I * 1e4).toFixed(2)}e-4 m⁴ · EI = {EI.toFixed(0)} kN·m²
              </div>
            </div>
          </div>
        </div>

        {/* ------------------- HOJA DE DIAGRAMAS ------------------- */}
        <div ref={wrapRef} className="vc-sheet vc-anim">
          {res.error ? (
            <div className="vc-err">{res.error}</div>
          ) : (
            <div onMouseMove={onMove} onMouseLeave={() => setHover(null)}>
              <Elevation
                W={W} xs={xs} spans={spans} supports={supports} loads={loads}
                Ltot={Ltot} hover={hover} PAD={PAD}
              />
              <Diagram
                title="Cortante  V(x)" unit="kN" color="var(--shear)" data={res.V}
                W={W} xs={xs} Ltot={Ltot} hover={hover} sample={sample} bounds={res.bounds}
                ext={res.eV} flip={false} scaleTo={1} h={130}
              />
              <Diagram
                title="Momento  M(x)" unit="kN·m" color="var(--moment)" data={res.M}
                W={W} xs={xs} Ltot={Ltot} hover={hover} sample={sample} bounds={res.bounds}
                ext={res.eM} flip={true} scaleTo={1} h={150}
                note="(+) dibujado del lado en tracción"
              />
              <Diagram
                title="Deformada  δ(x)" unit="mm" color="var(--defl)" data={res.D}
                W={W} xs={xs} Ltot={Ltot} hover={hover} sample={sample} bounds={res.bounds}
                ext={res.eD} flip={false} scaleTo={1000} h={120}
              />
              <div className="vc-panel" style={{ padding: "12px 14px" }}>
                <div className="vc-lab" style={{ marginBottom: 8 }}>Reacciones y valores de control</div>
                <table className="vc-react">
                  <thead>
                    <tr>
                      <th>Nodo</th><th>x (m)</th><th>Rv (kN)</th><th>M (kN·m)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {res.reactions.map((r, i) =>
                      r ? (
                        <tr key={i}>
                          <td>{i + 1} · {r.type === "empotrado" ? "empotrado" : "apoyo"}</td>
                          <td>{r.x.toFixed(2)}</td>
                          <td>{fmt(r.V)}</td>
                          <td>{r.type === "empotrado" ? fmt(-r.M) : "—"}</td>
                        </tr>
                      ) : null
                    )}
                  </tbody>
                </table>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 22, marginTop: 14 }}>
                  <Ctrl l="V máx" v={`${fmt(res.eV.abs)} kN`} c="var(--shear)" />
                  <Ctrl l="M⁺ máx" v={`${fmt(res.eM.max.v)} kN·m`} c="var(--moment)" />
                  <Ctrl l="M⁻ máx" v={`${fmt(res.eM.min.v)} kN·m`} c="var(--moment)" />
                  <Ctrl
                    l="δ máx"
                    v={`${fmt(res.eD.abs * 1000)} mm  ·  L/${res.eD.abs > 1e-9 ? Math.round(Ltot / res.eD.abs) : "∞"}`}
                    c="var(--defl)"
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Ctrl({ l, v, c }) {
  return (
    <div>
      <div className="stat-l">{l}</div>
      <div className="stat-v" style={{ color: c }}>{v}</div>
    </div>
  );
}

/* --------- Elevación: dibujo estructural de la viga --------- */
function Elevation({ W, xs, spans, supports, loads, Ltot, hover, PAD }) {
  const H = 132;
  const yBeam = 62;
  const beamT = 11;
  let acc = 0;
  const nodes = [0];
  spans.forEach((s) => { acc += s.L; nodes.push(acc); });

  return (
    <div className="vc-panel">
      <svg width={W} height={H} style={{ display: "block" }}>
        <defs>
          <marker id="ar" markerWidth="8" markerHeight="8" refX="3" refY="6"
                  orient="0" markerUnits="userSpaceOnUse">
            <path d="M0,0 L3,6 L6,0" fill="none" stroke="#15232A" strokeWidth="1.1" />
          </marker>
          <pattern id="hatch" width="5" height="5" patternTransform="rotate(45)" patternUnits="userSpaceOnUse">
            <line x1="0" y1="0" x2="0" y2="5" stroke="#63747B" strokeWidth="1" />
          </pattern>
        </defs>

        {/* cargas distribuidas */}
        {spans.map((s, i) => {
          const x0 = xs(nodes[i]), x1 = xs(nodes[i + 1]);
          if (Math.abs(s.w) < 1e-9) return null;
          const n = Math.max(2, Math.round((x1 - x0) / 22));
          const top = yBeam - 30;
          return (
            <g key={i} stroke="#15232A" strokeWidth="1">
              <line x1={x0} y1={top} x2={x1} y2={top} />
              {Array.from({ length: n + 1 }).map((_, j) => {
                const x = x0 + ((x1 - x0) * j) / n;
                return <line key={j} x1={x} y1={top} x2={x} y2={yBeam - 3} markerEnd="url(#ar)" />;
              })}
              <text x={(x0 + x1) / 2} y={top - 6} textAnchor="middle" fill="#15232A" stroke="none"
                style={{ font: "500 11px 'IBM Plex Mono',monospace" }}>
                w = {s.w} kN/m
              </text>
            </g>
          );
        })}

        {/* cargas puntuales */}
        {loads.map((l, i) => {
          const x = xs(Math.min(Math.max(l.x, 0), Ltot));
          return (
            <g key={i}>
              <line x1={x} y1={yBeam - 46} x2={x} y2={yBeam - 3} stroke="#15232A" strokeWidth="1.6" markerEnd="url(#ar)" />
              <text x={x + 5} y={yBeam - 40} fill="#15232A" style={{ font: "600 11px 'IBM Plex Mono',monospace" }}>
                {l.P} kN
              </text>
            </g>
          );
        })}

        {/* viga */}
        <rect x={xs(0)} y={yBeam} width={xs(Ltot) - xs(0)} height={beamT} fill="#15232A" />

        {/* apoyos */}
        {nodes.map((nx, i) => {
          const x = xs(nx);
          const t = supports[i]?.type ?? "apoyo";
          const y = yBeam + beamT;
          if (t === "libre") return null;
          if (t === "apoyo")
            return (
              <g key={i}>
                <path d={`M${x},${y} L${x - 10},${y + 16} L${x + 10},${y + 16} Z`} fill="#fff" stroke="#15232A" strokeWidth="1.4" />
                <rect x={x - 15} y={y + 16} width="30" height="6" fill="url(#hatch)" />
                <line x1={x - 15} y1={y + 16} x2={x + 15} y2={y + 16} stroke="#15232A" strokeWidth="1.4" />
              </g>
            );
          return (
            <g key={i}>
              <line x1={x} y1={yBeam - 8} x2={x} y2={y + 8} stroke="#15232A" strokeWidth="2.5" />
              <rect x={i === 0 ? x - 9 : x - 1} y={yBeam - 8} width="10" height={beamT + 16} fill="url(#hatch)" />
            </g>
          );
        })}

        {/* línea de cotas */}
        <g stroke="#63747B" strokeWidth="1">
          <line x1={xs(0)} y1={H - 22} x2={xs(Ltot)} y2={H - 22} />
          {nodes.map((nx, i) => (
            <line key={i} x1={xs(nx)} y1={H - 27} x2={xs(nx)} y2={H - 17} />
          ))}
        </g>
        {spans.map((s, i) => (
          <text key={i} x={(xs(nodes[i]) + xs(nodes[i + 1])) / 2} y={H - 7} textAnchor="middle" fill="#63747B"
            style={{ font: "400 10.5px 'IBM Plex Mono',monospace" }}>
            {s.L.toFixed(2)} m
          </text>
        ))}

        {hover != null && (
          <line x1={xs(hover)} y1={8} x2={xs(hover)} y2={H - 30} stroke="#15232A" strokeWidth="1" strokeDasharray="3 3" opacity="0.55" />
        )}
      </svg>
    </div>
  );
}

/* --------- Panel de diagrama genérico --------- */
function Diagram({ title, unit, color, data, W, xs, Ltot, hover, sample, bounds, ext, flip, scaleTo, h, note }) {
  const pad = 26;
  const usable = h - pad * 2;
  const amp = Math.max(ext.abs, 1e-9);
  const y0 = pad + usable / 2;
  const sgn = flip ? -1 : 1;
  const ys = (v) => y0 - (sgn * v * (usable / 2)) / amp;

  let dPath = "";
  data.forEach((p, i) => {
    dPath += `${i === 0 ? "M" : "L"}${xs(p.x).toFixed(2)},${ys(p.v).toFixed(2)}`;
  });
  const area =
    `M${xs(data[0].x).toFixed(2)},${y0.toFixed(2)}L` +
    data.map((p) => `${xs(p.x).toFixed(2)},${ys(p.v).toFixed(2)}`).join("L") +
    `L${xs(data[data.length - 1].x).toFixed(2)},${y0.toFixed(2)}Z`;

  const hv = hover != null ? sample(data, hover) : null;

  return (
    <div className="vc-panel">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", padding: "8px 14px 0" }}>
        <div className="vc-lab" style={{ margin: 0, color }}>{title}</div>
        <div style={{ font: "500 12px 'IBM Plex Mono',monospace", color: hv == null ? "#63747B" : color }}>
          {hv == null ? (note ?? `máx ${fmt(ext.abs * scaleTo)} ${unit}`) : `${fmt(hv * scaleTo)} ${unit}`}
        </div>
      </div>
      <svg width={W} height={h} style={{ display: "block" }}>
        {bounds.map((b, i) => (
          <line key={i} x1={xs(b)} y1={pad - 8} x2={xs(b)} y2={h - pad + 8} stroke="#DCE4E1" strokeWidth="1" />
        ))}
        <path d={area} fill={color} opacity="0.13" />
        <path d={dPath} fill="none" stroke={color} strokeWidth="1.9" strokeLinejoin="round" />
        <line x1={xs(0)} y1={y0} x2={xs(Ltot)} y2={y0} stroke="#15232A" strokeWidth="1" />
        {[ext.max, ext.min].map((e, i) =>
          Math.abs(e.v) > 1e-6 ? (
            <g key={i}>
              <circle cx={xs(e.x)} cy={ys(e.v)} r="2.6" fill={color} />
              <text x={xs(e.x)} y={ys(e.v) + (ys(e.v) > y0 ? 14 : -8)} textAnchor="middle" fill={color}
                style={{ font: "600 10.5px 'IBM Plex Mono',monospace" }}>
                {fmt(e.v * scaleTo, 1)}
              </text>
            </g>
          ) : null
        )}
        {hover != null && (
          <g>
            <line x1={xs(hover)} y1={pad - 8} x2={xs(hover)} y2={h - pad + 8} stroke="#15232A" strokeWidth="1" strokeDasharray="3 3" opacity="0.55" />
            <circle cx={xs(hover)} cy={ys(hv)} r="3.4" fill="#fff" stroke={color} strokeWidth="1.8" />
          </g>
        )}
        <text x={6} y={y0 + 3.5} fill="#63747B" style={{ font: "400 9.5px 'IBM Plex Mono',monospace" }}>
          {unit}
        </text>
      </svg>
    </div>
  );
}
