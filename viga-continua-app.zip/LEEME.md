# Viga Continua — instalar en el celular

Dos caminos. El primero toma 2 minutos; el segundo te deja una app real que
abre sin internet y con su propio ícono.

---

## Opción A — Publicar el artifact (rápido)

1. En la app de Claude, abre el artifact y toca **Publicar**.
2. Copia el enlace público que te da.
3. Abre ese enlace en **Safari** (iPhone) o **Chrome** (Android).
4. Agrégalo a la pantalla de inicio:
   - iPhone: botón Compartir → **Agregar a pantalla de inicio**
   - Android: menú ⋮ → **Agregar a la pantalla principal**

Queda como un ícono más. Necesita internet para abrir, y el enlace es público
(cualquiera con la URL lo ve). Si algún día lo despublicas, no se puede volver
a publicar ese mismo artifact.

---

## Opción B — Tu propia app, sin internet (recomendada)

Estos archivos son la app completa: el HTML ya trae React y todo el cálculo
adentro, no depende de ningún servidor.

### 1. Súbelos a GitHub Pages (gratis, permanente)

1. Crea una cuenta en github.com si no tienes.
2. Nuevo repositorio → nómbralo `viga` → marca **Public** → Create.
3. **Add file → Upload files** y sube los 5 archivos:
   `index.html`, `manifest.webmanifest`, `sw.js`, `icon-180.png`, `icon-512.png`
4. Commit.
5. **Settings → Pages** → Source: *Deploy from a branch* → Branch: `main` / `root` → Save.
6. En un minuto tendrás la URL: `https://TUUSUARIO.github.io/viga/`

### 2. Instálala

Abre esa URL en el celular y agrégala a la pantalla de inicio (mismos pasos de
arriba). El *service worker* guarda todo en el dispositivo: después de la
primera visita **funciona en modo avión**, ideal para el laboratorio o el aula.

### Alternativas al paso 1
- **Netlify Drop** (app.netlify.com/drop): arrastras la carpeta y listo.
- **Cloudflare Pages**: igual de simple, también gratis.
- Cualquier hosting que tengas. Solo necesita servir archivos estáticos por HTTPS
  (el service worker no funciona sobre HTTP simple).

---

## Notas

- Las tipografías se cargan de Google Fonts. Sin internet la app funciona igual,
  solo cambia a las fuentes del sistema.
- Para actualizarla: reemplaza `index.html` en el repo y sube el número de versión
  en `sw.js` (`viga-continua-v1` → `v2`), si no el celular sigue mostrando la caché vieja.
- El código fuente en JSX está en `analizador-viga-continua.jsx`, por si quieres
  seguir modificándolo en Claude.
